'use strict';

let _autofillTimer = null;

async function init() {
  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js').catch(() => {});
  }

  // Load persisted theme
  loadTheme();

  // Open IndexedDB
  await initDB();

  // Load default library
  await loadLibrary('shows');

  // Wire up all events
  _bindEvents();
}

function _bindEvents() {
  // Theme toggle
  document.getElementById('theme-toggle').addEventListener('click', () => {
    toggleTheme();
    applyAccent(getCurrentLib());
  });

  // Library tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => loadLibrary(tab.dataset.lib));
  });

  // Search + autofill
  document.getElementById('search-input').addEventListener('input', e => {
    const q = e.target.value.trim();
    setSearchQuery(q);
    renderList();

    clearTimeout(_autofillTimer);
    if (q.length >= 2) {
      _autofillTimer = setTimeout(async () => {
        const results = await autofillSearch(getCurrentLib(), q);
        renderAutofillResults(results);
      }, 320);
    } else {
      document.getElementById('autofill-results').classList.add('hidden');
      document.getElementById('autofill-results').innerHTML = '';
    }
  });

  // Add button — create item from current search text
  document.getElementById('add-btn').addEventListener('click', () => {
    const q = document.getElementById('search-input').value.trim();
    if (!q) return;
    createItemFromTitle(q).then(() => {
      document.getElementById('search-input').value = '';
      document.getElementById('autofill-results').classList.add('hidden');
      document.getElementById('autofill-results').innerHTML = '';
      setSearchQuery('');
    });
  });

  // Enter key in search also adds
  document.getElementById('search-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const q = e.target.value.trim();
      if (!q) return;
      createItemFromTitle(q).then(() => {
        e.target.value = '';
        document.getElementById('autofill-results').classList.add('hidden');
        document.getElementById('autofill-results').innerHTML = '';
        setSearchQuery('');
      });
    }
  });

  // Filter buttons (event delegation)
  document.getElementById('filter-bar').addEventListener('click', e => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;

    const type = btn.dataset.type;
    const raw = btn.dataset.value;
    const value = type === 'rating' ? parseInt(raw, 10) : raw;

    toggleFilter(type, value);
    btn.classList.toggle('active');
    renderList();
  });

  // Sort
  document.getElementById('sort-select').addEventListener('change', e => {
    setSort(e.target.value);
    renderList();
  });

  // Close detail overlay by clicking background
  document.getElementById('overlay-bg').addEventListener('click', closeDetail);

  // Close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeDetail();
  });
}

document.addEventListener('DOMContentLoaded', init);
